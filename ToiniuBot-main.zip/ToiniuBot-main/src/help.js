const help = (prefix) => {
	return `
• ──── 𖤐 ──── •
*Oiioii esses são alguns dos meus comandos:*

【™̴ᩕ̟ᩤ𝑭𝑹𝜟͢𝑵𝑪𝑿↯¹⧔ᩕ 🇨🇦】
• ──── 𖤐 ──── •
  │
  ├─⧔𖤐ᩕ INFORMAÇÕES
  ├─⧔ᩕ Prefix: 【  ${prefix}  】
  ├─⧔ᩕ Criador : FRANCX
  ├─⧔ᩕ Wa.me/+56965554504
  │
• ──── 𖤐 ──── •
   SOBRE【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}info
  ├─ ⧔ᩕ ${prefix}blocklist
  ├─ ⧔ᩕ ${prefix}chatlist
  ├─ ⧔ᩕ ${prefix}ping
  ├─⧔ᩕ ${prefix}bugreport
  ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
• ──── 𖤐 ──── •
   FAZER【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}sticker
  ├─ ⧔ᩕ ${prefix}stickergif
  ├─ ⧔ᩕ ${prefix}toimg
  ├─ ⧔ᩕ ${prefix}tomp3
  ├─ ⧔ᩕ ${prefix}bpink
  ├─ ⧔ᩕ ${prefix}marvellogo
  ├─ ⧔ᩕ ${prefix}snowwrite
  ├─ ⧔ᩕ ${prefix}3dtext
  ├─ ⧔ᩕ ${prefix}ninjalogo
  ├─ ⧔ᩕ ${prefix}water
  ├─ ⧔ᩕ ${prefix}firetext
  ├─ ⧔ᩕ ${prefix}logowolf
  ├─ ⧔ᩕ ${prefix}logowolf2
  ├─ ⧔ᩕ ${prefix}phlogo
  ├─ ⧔ᩕ ${prefix}glitch
  ├─ ⧔ᩕ ${prefix}neonlogo
  ├─ ⧔ᩕ ${prefix}neonlogo2
  ├─ ⧔ᩕ ${prefix}lionlogo
  ├─ ⧔ᩕ ${prefix}jokerlogo
  ├─ ⧔ᩕ ${prefix}shadow
  ├─ ⧔ᩕ ${prefix}burnpaper
  ├─ ⧔ᩕ ${prefix}coffee
  ├─ ⧔ᩕ ${prefix}lovepaper
  ├─ ⧔ᩕ ${prefix}woodblock
  ├─ ⧔ᩕ ${prefix}qowheart
  ├─ ⧔ᩕ ${prefix}mutgrass
  ├─ ⧔ᩕ ${prefix}undergocean
  ├─ ⧔ᩕ ${prefix}woodenboards
  ├─ ⧔ᩕ ${prefix}wolfmetal
  ├─ ⧔ᩕ ${prefix}metalictglow
  ├─ ⧔ᩕ ${prefix}8bit
  ├─ ⧔ᩕ ${prefix}ttp
  ├─ ⧔ᩕ ${prefix}herrypotter
  ├─ ⧔ᩕ ${prefix}pubglogo
  ├─ ⧔ᩕ ${prefix}quotemaker
  │
• ──── 𖤐 ──── •
   MEDIA【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}trendtwit
  ├─ ⧔ᩕ ${prefix}randomkpop
  ├─ ⧔ᩕ ${prefix}ytsearch
  │
• ──── 𖤐 ──── •
  EDUCAÇÃO【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}wiki
  ├─ ⧔ᩕ ${prefix}wikien
  ├─ ⧔ᩕ ${prefix}nulis
  ├─ ⧔ᩕ ${prefix}quotes
  ├─ ⧔ᩕ ${prefix}quotes2
  ├─ ⧔ᩕ ${prefix}artinama
  │
• ──── 𖤐 ──── •
 KERANG AJAIB【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}apakah
  ├─ ⧔ᩕ ${prefix}kapankah
  ├─ ⧔ᩕ ${prefix}rate
  ├─ ⧔ᩕ ${prefix}bisakah
  │
• ──── 𖤐 ──── •
  DOWNLOAD【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}images
  ├─ ⧔ᩕ ${prefix}ytmp3
  ├─ ⧔ᩕ ${prefix}ytmp4
  ├─ ⧔ᩕ ${prefix}tiktok
  ├─ ⧔ᩕ ${prefix}joox
  │
• ──── 𖤐 ──── •
    MEME【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}meme
  ├─ ⧔ᩕ ${prefix}memeindo
  │
• ──── 𖤐 ──── •
    SOM【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}play
  ├─ ⧔ᩕ ${prefix}tts
  │
• ──── 𖤐 ──── •
   MÚSICA【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}lirik
  ├─ ⧔ᩕ ${prefix}chord
  │
• ──── 𖤐 ──── •
   ISLAM【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}quran
  │
• ──── 𖤐 ──── •
    STALK【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}tiktokstalk
  ├─ ⧔ᩕ ${prefix}igstalk

• ──── 𖤐 ──── •
    WIBU【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}neonime
  ├─ ⧔ᩕ ${prefix}pokemon
  ├─ ⧔ᩕ ${prefix}loli
  ├─ ⧔ᩕ ${prefix}waifu
  ├─ ⧔ᩕ ${prefix}randomanime
  ├─ ⧔ᩕ ${prefix}husbu
  ├─ ⧔ᩕ ${prefix}husbu2
  ├─ ⧔ᩕ ${prefix}wait
  ├─ ⧔ᩕ ${prefix}nekonime
  │
• ──── 𖤐 ──── •
  DIVERÇÃO【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}alay
  ├─ ⧔ᩕ ${prefix}gantengcek
  ├─ ⧔ᩕ ${prefix}watak
  ├─ ⧔ᩕ ${prefix}hobby
  ├─ ⧔ᩕ ${prefix}game
  ├─ ⧔ᩕ ${prefix}bucin
  ├─ ⧔ᩕ ${prefix}trust
  ├─ ⧔ᩕ ${prefix}dare
  ├─ ⧔ᩕ ${prefix}simi
  │
• ──── 𖤐 ──── •
 INFORMAÇÃO【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}bahasa
  ├─ ⧔ᩕ ${prefix}kodenegara
  ├─ ⧔ᩕ ${prefix}kbbi
  ├─ ⧔ᩕ ${prefix}fakta
  ├─ ⧔ᩕ ${prefix}infocuaca
  ├─ ⧔ᩕ ${prefix}infogempa
  ├─ ⧔ᩕ ${prefix}jadwaltvnow
  ├─ ⧔ᩕ ${prefix}covid
  │
• ──── 𖤐 ──── •
   DONO【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}setprefix
  ├─ ⧔ᩕ ${prefix}block
  ├─ ⧔ᩕ ${prefix}bc
  ├─ ⧔ᩕ ${prefix}bcgc
  ├─ ⧔ᩕ ${prefix}clone
  ├─ ⧔ᩕ ${prefix}clearall
  │
• ──── 𖤐 ──── •
  OUTROS【✔】
• ──── 𖤐 ──── •
  │
  ├─ ⧔ᩕ ${prefix}send
  ├─ ⧔ᩕ ${prefix}wame
  ├─ ⧔ᩕ ${prefix}virtex
  ├─ ⧔ᩕ ${prefix}exe
  ├─ ⧔ᩕ ${prefix}qrcode
  ├─ ⧔ᩕ ${prefix}afk
  ├─ ⧔ᩕ ${prefix}timer
  ├─ ⧔ᩕ ${prefix}fml
  ├─ ⧔ᩕ ${prefix}fml2
  ├─ ⧔ᩕ ${prefix}afk
  ├─ ⧔ᩕ ${prefix}timer
  ├─ ⧔ᩕ ${prefix}fml
  └─ ⧔ᩕ ${prefix}fml2
`
}

exports.help = help
